import os
from cudatext import *
from cudax_lib import get_translation

_ = get_translation(__file__) # I18N


class Command:

    def __init__(self):
        pass

