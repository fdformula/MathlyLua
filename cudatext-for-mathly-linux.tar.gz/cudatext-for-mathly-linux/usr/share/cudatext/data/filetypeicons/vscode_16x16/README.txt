Visual Studio Code icons
converted to 16x16 PNG using ImageMagick
