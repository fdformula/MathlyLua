        s = '''
        file lines count: {cnt}
        option_int: {i}
        option_bool: {b}
        '''.format(
                cnt = ed.get_line_count(),
                i = option_int,
                b = option_bool,
            )
        msg_box(s, MB_OK)

