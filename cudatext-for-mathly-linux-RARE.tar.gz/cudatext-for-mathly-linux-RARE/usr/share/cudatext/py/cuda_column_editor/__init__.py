import os
from cudatext import *
from cudax_lib import get_translation

_   = get_translation(__file__)  # I18N

fn_config = os.path.join(app_path(APP_DIR_SETTINGS), 'cuda_ColumnEditor.ini')

option_int = 100
option_bool = True

def bool_to_str(v): return '1' if v else '0'
def str_to_bool(s): return s=='1'

class Command:

    def __init__(self):

        global option_int
        global option_bool
        option_int = int(ini_read(fn_config, 'op', 'option_int', str(option_int)))
        option_bool = str_to_bool(ini_read(fn_config, 'op', 'option_bool', bool_to_str(option_bool)))

    def config(self):

        ini_write(fn_config, 'op', 'option_int', str(option_int))
        ini_write(fn_config, 'op', 'option_bool', bool_to_str(option_bool))
        file_open(fn_config)

    def digits(self, n): # number of digits
        if n == 0: return 1
        i = 0
        while n > 0:
            i = i + 1
            n = n // 10
        return i

    def run(self): # david wang 9/26/2024
        carets = ed.get_carets()
        if len(carets) == 1:
            msg_box('Please select a column block first.', MB_OK)
            return
        info = dlg_input_ex(5, 'Formatted numbers to be inserted',
            label1='Prefix', text1='',
            label2='Start', text2='0',
            label3='Step', text3='1',
            label4='Digit Leading Char', text4='0',
            label5='Suffix', text5='')
        if info == None: return()
        start = int(info[1])
        step = int(info[2])
        leading = info[3]
        if leading == '': leading = ' '
        if len(leading) > 1: leading = leading[0:1]
        maxdigits = self.digits(start + len(carets) * step)
        lineno = start
        for caret in carets:
            txt = info[0] + leading * (maxdigits - self.digits(lineno)) + str(lineno) + info[4]
            caret0 = caret[0]
            if caret0 > caret[2]: caret0 = caret[2]
            ed.insert(caret0, caret[1], txt)
            lineno = lineno + step
