
This directory contains dictionaries for the hunspell backend to enchant.

