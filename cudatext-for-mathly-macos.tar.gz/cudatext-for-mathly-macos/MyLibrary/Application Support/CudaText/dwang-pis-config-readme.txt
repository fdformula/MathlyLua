You may need to configure the following three variables in 
/usr/share/cudatext/py/cuda_ex_terminal/__init__.py

    perl = 'perl'
    pis_folder = '/usr/share/perl-inline-script/'
    browser = 'firefox'
