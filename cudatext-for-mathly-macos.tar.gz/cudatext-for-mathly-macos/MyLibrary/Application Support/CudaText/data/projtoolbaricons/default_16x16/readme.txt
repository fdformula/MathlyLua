Font Awesome - 973 vector (SVG) icons 
Dave Gandy
http://fontawesome.io/
https://www.iconfinder.com/iconsets/font-awesome
