Icon "gear" by Atlas
https://www.iconfinder.com/iconsets/4web-3
License: Creative Commons (Attribution 3.0 Unported)
http://creativecommons.org/licenses/by/3.0/
