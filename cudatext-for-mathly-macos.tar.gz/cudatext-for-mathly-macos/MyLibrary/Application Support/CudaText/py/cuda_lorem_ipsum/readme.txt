Plugin for CudaText.
Gives dialog to insert "lorem upsum" (standard template) text.
Can insert N sentences (dot-separated), or N paragraphs (blank line separated) or N paragraphs separated by <p> HTML tags.
N is the option in the dialog.
Multi-carets are supported, text will be inserted at multi-carets.

Author: Alexey Torgashin (CudaText)
License: MIT