Plugin for CudaText.
Shows "Tabs" panel in the side-panel, with the list of opened editor-tabs.
Updates list when a file is opened or closed or changed.
Handles click on this list. Handles context menu over this list.

Author: Alexey Torgashin (CudaText)
License: MIT
