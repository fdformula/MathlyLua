# cuda_ext
Additional commands for CudaText in Commands dialog and Plugins menu

Menu `Plugins/Cuda-Ext` items

![default](https://user-images.githubusercontent.com/7419630/36963720-70e41e86-2065-11e8-984b-902afba42503.png)

![default](https://user-images.githubusercontent.com/7419630/36963775-9cadd57a-2065-11e8-98ee-23aac4ac696f.png)

![default](https://user-images.githubusercontent.com/7419630/36963821-c5f6a06a-2065-11e8-8bf2-3dd4961a4d5a.png)

![default](https://user-images.githubusercontent.com/7419630/36963852-e5b1698a-2065-11e8-98ab-5a8bfa24c05c.png)

![default](https://user-images.githubusercontent.com/7419630/36963889-020ac9c8-2066-11e8-9fa5-e2cab4debc6f.png)

![default](https://user-images.githubusercontent.com/7419630/36963966-4205ce88-2066-11e8-8830-c2c80dcc1366.png)

![default](https://user-images.githubusercontent.com/7419630/36964026-6844d198-2066-11e8-9aac-7bf82571f4ed.png)

![default](https://user-images.githubusercontent.com/7419630/36964057-7e7cd8de-2066-11e8-82a5-ebca03eb10ca.png)

![default](https://user-images.githubusercontent.com/7419630/36964078-90837844-2066-11e8-8d8a-1f931e75dd65.png)

![default](https://user-images.githubusercontent.com/7419630/36964101-a6d735f4-2066-11e8-9d3c-1d1940a3b284.png)

![default](https://user-images.githubusercontent.com/7419630/36964146-c5b5d192-2066-11e8-9604-a6e8c788326f.png)
