MASKS_IGNORE = '.rar .exe .dll .git .svn'
MASKS_ZIP = '.zip .7z .tar .gz .tgz .rar .xz .cab .deb .rpm'
MASKS_IMAGES = '.png .jpg .jpeg .gif .bmp .ico .webp .psd .tga .cur'
MASKS_BINARY = '.exe .dll .o .a .msi .lib .obj .pdf .so'
