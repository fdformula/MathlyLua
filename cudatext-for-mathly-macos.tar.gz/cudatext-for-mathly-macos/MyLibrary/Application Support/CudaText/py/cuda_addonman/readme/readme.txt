To read info about plugins, double-click these Wiki links:
https://wiki.freepascal.org/CudaText#Add-ons
https://wiki.freepascal.org/CudaText_plugins
