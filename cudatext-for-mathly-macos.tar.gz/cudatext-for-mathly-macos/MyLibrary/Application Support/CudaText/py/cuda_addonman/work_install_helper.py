def after_install(module):
    #print('Installed module:', module)
    #check it for lexers/themes
    pass
