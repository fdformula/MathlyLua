-- mod-version:3
-- by David Wang, dwang@liberty.edu, on 12/28/2025
-- "borrowed" and customized from language_c.lua
local syntax = require "core.syntax"

-- integer suffix combinations as a regex
local isuf = [[(?:[lL][uU]|ll[uU]|LL[uU]|[uU][lL]\b|[uU]ll|[uU]LL|[uU]|[lL]\b|ll|LL)?]]
-- float suffix combinations as a Lua pattern / regex
local fsuf = "[fFlL]?"
-- number with digit separator as a regex non-capturing group
local digitsep = [[(?:\d[\d']*)]]

syntax.add {
  name = "C",
  files = { "%.bc$" },
  comment = "#",
  patterns = {
    { pattern = "#.*",                                                            type = "comment" },
    { pattern = { '"', '"', '\\' },                                                type = "string"  },
    { pattern = { "'", "'", '\\' },                                                type = "string"  },
    { regex   = "0x[0-9a-fA-F][0-9a-fA-F']*"..isuf,                                type = "number"  },
    { regex   = "0()[0-7][0-7']*"..isuf,                                           type = { "keyword", "number" } },
    { regex   = digitsep.."\\.?"..digitsep.."?(?:[Ee][-+]?"..digitsep..")?"..fsuf, type = "number" },
    { regex   = "\\."..digitsep.."(?:[Ee][-+]?"..digitsep..")?"..fsuf,             type = "number" },
    { pattern = "[%+%-=/%*%^%%<>!~|&]",                                            type = "operator" },
    -- all other functions
    { pattern = "[%a_][%w_]*%f[(]",      type = "function" },
    { pattern = "%f[#]#%s*[%a_][%w_]*",  type = "keyword"   },
    -- Everything else to make the tokenizer work properly
    { pattern = "[%a_][%w_]*",           type = "symbol" },
  },
  symbols = {
    ["auto"]     = "keyword",
    ["break"]    = "keyword",
    ["continue"] = "keyword",
    ["define"]   = "keyword",
    ["else"]     = "keyword",
    ["for"]      = "keyword",
    ["halt"]     = "keyword",
    ["if"]       = "keyword",
    ["last"]     = "literal",
    ["length"]   = "keyword2",
    ["limits"]   = "literal",
    ["quit"]     = "keyword",
    ["read"]     = "keyword2",
    ["return"]   = "keyword",
    ["scale"]    = "literal",
    ["sqrt"]     = "keyword2",
    ["warranty"] = "literal",
    ["while"]    = "keyword",
  },
}
