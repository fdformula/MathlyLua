-- mod-version:3
-- by David Wang, dwang@liberty.edu, on 12/24/2025
--
-- This plugin is primarily for Lua + Mathly. Only one interpreter is allowed at a time. To use another
-- interpreter, you may enter the interpreter terminal, and press ctrl-c or execute commands like
-- os.exit(), exit, quit, exit(), etc., to exit the present interpreter. Then, go to the very file in
-- the editor and press F2 to start the associated interpreter.
--
local core = require "core"
local command = require "core.command"
local term = require "terminal" -- Adjust path if necessary

local win_browser = 'C:/Program Files/Mozilla Firefox/firefox.exe'
local linux_browser = 'firefox'
local mac_browser = '/Applications/Firefox.app/Contents/MacOS/firefox'

local lua_mathly = (PLATFORM == "Windows" and 'c:/mathly/bin/lua.exe') or (PLATFORM == "Mac OS X" and '/usr/local/bin/lua') or "lua"
lua_mathly = lua_mathly .. ' -i -e "mathly = require(\'mathly\')"'

local lua_doc_folder = '/usr/local/share/lua/doc/' -- linux & macos
if PLATFORM == "Windows" then lua_doc_folder = 'C:/mathly/doc/' end

local lua_manual_url     = 'file:///' .. lua_doc_folder .. 'manual.html'
local lua_ref_manual_url = 'file:///' .. lua_doc_folder .. 'lua5_4.html'
local mathly_manual_url  = 'file:///' .. lua_doc_folder .. 'mathly.html'

local interpreters = { -- file name extensions and associated interpreters
  bc   = 'bc -l -q', -- you may provide the path, e.g., 'c:/cygwin/bin/bc.exe'
  htm  = lua_mathly,
  html = lua_mathly,
  jl   = 'julia',
  lua  = lua_mathly,
  m    = 'octave',
  py   = 'python',
  r    = 'R',
  rb   = 'irb',
  sh   = 'bash'
}

local function get_fname_ext(fname)
  if fname then
    local i = #fname
    while i > 0 do
      local c = fname:sub(i, i)
      if c == '\\' or c == '/' then break end
      if c == '.' then return string.lower(fname:sub(i + 1, #fname)) end
      i = i - 1
    end
  end
  return 'lua'
end

local function interpreter()
  local ext = get_fname_ext(core.active_view.doc.filename or '')
  return interpreters[ext] or lua_mathly
end

local function get_path(path)
  local i = #path
  while i > 0 do
    local c = path:sub(i, i)
    if c == '\\' or c == '/' then break end
    i = i - 1
  end
  return path:sub(1, i)
end

local function _send_code_to_term(terminal, txt)
  txt = txt:gsub('\n', '\r')
  terminal:input(txt .. "\r")
end

local function start_interpreter()
  local terminal = core.terminal_view
  if terminal == nil then
    term.class.open_terminal()
    terminal = core.terminal_view
  end
  _send_code_to_term(terminal, "cd \"" .. get_path(core.active_view.doc.abs_filename or '') .. "\"")
  _send_code_to_term(terminal, interpreter())
  return terminal
end

local function get_terminal()
  return core.terminal_view or start_interpreter()
end

local function send_code_to_terminal(txt)
  if txt and #txt > 0 then
    _send_code_to_term(get_terminal(), txt)
  end
end

local function is_word_char(c) -- char c is part of a word
  if c == "" then return false end
  local d = string.byte(c)
  return (d >= 97 and d <= 122) or (d >= 65 and d <= 90) or (d >= 48 and d <= 57) or d == 95 or d == 46 or d == 58 -- a~zA~Z0~9_.:
end

local function get_current_line_column()
  local doc = core.active_view.doc
  for i, r1, c1, r2, c2 in doc:get_selections(true) do
    return i, r1, c1 -- current index, line, column
  end
end

command.add(nil, { -- run selected commands or current line
  ["mathly:send-selection"] = function()
    local doc = core.active_view.doc
    local txt
    if doc:has_any_selection() then
      txt = doc:get_selection_text() -- doc:get_text(doc:get_selection())
    else
      local idx, r, c = get_current_line_column()
      txt = doc:get_text(r, 1, r, math.huge)
      r = r + 1
      doc:set_selections(idx, r, c, r, c) -- move to next line
    end
    send_code_to_terminal(txt)
  end
})

command.add(nil, { -- run current script file
  ["mathly:send-all"] = function()
    local doc = core.active_view.doc
    local ext = string.lower(get_fname_ext(doc.filename or ''))
    if ext == 'htm' or ext == 'html' then
      local fmt, url = string.format, doc.abs_filename
      url = url:gsub('\\', '/')
      url = url:gsub(' ', '%%20')
      url = url:gsub('&', '%%26')
      url = 'file:///' .. url
      if PLATFORM == "Windows" then
        send_code_to_terminal("os.execute('" .. fmt('"%s" %s', win_browser, url) .. "')")
      elseif PLATFORM == "Mac OS X" then
        send_code_to_terminal("os.execute('" .. fmt('%s %s', mac_browser, url) .. "')")
      else
        send_code_to_terminal("os.execute('" .. fmt('%s %s', linux_browser, url) .. "')")
      end
    else
      send_code_to_terminal(doc:get_text(1, 1, math.huge, math.huge))
    end
  end
})

local function get_current_word(txt, col) -- txt line @ column c
  local w = ''
  for i = col, 1, -1 do
    local c = txt:sub(i, i)
    if not is_word_char(c) then break end
    w = c .. w
  end
  for i = col + 1, #txt do
    local c = txt:sub(i, i)
    if not is_word_char(c) then break end
    w = w .. c
  end
  return w
end

local function is_in(x, v)
  for _, val in pairs(v) do
    if x == val then return true end
  end
  return false
end

local _open_url = nil -- this needs to stay outside the function, or it'll re-sniff every time...
local function open_url(url)
  local fmt = string.format
  if not _open_url then
    if PLATFORM == "Windows" then
      _open_url = function(url) -- it is super slow to directly run: os.execute(...)
        send_code_to_terminal("os.execute('" .. fmt('"%s" %s', win_browser, url) .. "')")
      end
    elseif PLATFORM == "Mac OS X" then
      _open_url = function(url)
        send_code_to_terminal("os.execute('" .. fmt('%s "%s"', mac_browser, url) .. "')")
      end
    else
      _open_url = function(url)
        send_code_to_terminal("os.execute('" .. fmt('%s "%s"', linux_browser, url) .. "')")
      end
    end
  end
  _open_url(url)
end

-- ported from cudatext/py/cuda_ex_terminal/__init__.py
command.add(nil, { -- open help on current function/keyword
  ["mathly:send-lua-help"] = function()
    local doc = core.active_view.doc
    local idx, r, c = get_current_line_column()
    local w = get_current_word(doc:get_text(r, 1, r, math.huge), c)
    if w:match("^%d*$") then w = '' end -- a number

    local url
    if w == '' then
      url = mathly_manual_url
    else
      local mathlyq = is_in(w, {
        'all', 'animate', 'any', 'apply', 'arc', 'axisnotsquare', 'axissquare', 'bin2dec', 'bin2hex', 'bin2oct', 'boxplot',
        'cat', 'cc', 'circle', 'clc', 'clear', 'contourplot', 'copy', 'corr', 'cross', 'dec2bin', 'dec2hex', 'dec2oct',
        'demathly', 'det', 'diag', 'diff', 'diff1', 'diff2', 'dir', 'directionfield', 'disp', 'display', 'div', 'dot',
        'dotplot', 'eps', 'eval', 'expand', 'eye', 'findroot', 'fliplr', 'flipud', 'format','freqpolygon', 'fstr2f',
        'fzero', 'gcd', 'hasindex', 'hex2bin', 'hex2dec', 'hex2oct', 'hist', 'hist1', 'histfreqpolygon', 'horzcat',
        'input', 'integral', 'integral2', 'integral3', 'inv', 'isdir', 'isempty', 'iseven', 'isfile', 'isinteger', 'ismatrix',
        'ismember', 'isodd', 'isvector', 'iswindows', 'lagrangepoly', 'length', 'line', 'linsolve', 'linspace',
        'ls', 'lu', 'manipulate', 'map', 'match', 'mathly', 'max', 'mean', 'merge', 'min', 'mod', 'mv', 'namedargs',
        'newtonpoly', 'norm', 'oct2bin', 'oct2dec', 'oct2hex', 'ones', 'parametriccurve2d', 'pareto', 'pie', 'plot',
        'plot3d', 'plotparametriccurve2d', 'plotparametriccurve3d', 'plotparametricsurface3d', 'plotsphericalsurface3d',
        'point', 'polarcurve2d', 'polyfit', 'polygon', 'polynomial', 'polyval', 'powermod', 'printf', 'prod', 'pwd', 'qq', 'qr', 'rand',
        'randi', 'randn', 'range', 'remake', 'repmat', 'reshape', 'reverse', 'rm', 'round', 'rr', 'rref', 'save', 'scatter',
        'seq', 'showaxes', 'showgridlines', 'showlegend', 'shownotlegend', 'shownotaxes', 'shownotgridlines', 'shownotxaxis',
        'shownotyaxis', 'showxaxis', 'showyaxis', 'size', 'sleep', 'slopefield', 'sort', 'sprintf', 'std', 'strcat',
        'submatrix', 'subtable', 'sum', 'tables', 'tblcat', 'text', 'tic', 'toc', 'transpose', 'tt', 'unique', 'var',
        'vectorangle', 'vectorfield2d', 'vertcat', 'wedge', 'who', 'zeros'})
      local basicq = (not mathlyq) and is_in(w, {'abs', 'acos', 'asin', 'atan', 'ceil', 'cos', 'deg', 'e', 'eps', 'exp',
        'floor', 'log', 'log10', 'phi', 'pi', 'rad', 'random', 'sin', 'sqrt', 'tan'})
      if mathlyq then
        url = mathly_manual_url .. '#' .. w
      elseif basicq then
        url = mathly_manual_url .. '#math'
      else
        url = lua_manual_url
        local prefix = w:sub(1, 4)
        if prefix ~= 'lua_' and prefix ~= 'luaL' then
          local f = w:match('[:|%.](.+)')
          if is_in(f, {'concat', 'insert', 'move', 'pack', 'remove', 'sort', 'unpack'}) then
            w = 'table.' .. f
          elseif is_in(f, {'dump', 'find', 'byte', 'format', 'gmatch', 'gsub', 'len', 'lower', 'match', 'char',
            'packsize', 'rep', 'reverse', 'sub', 'upper'}) then
            w = 'string.' .. f
          elseif is_in(f, {'close', 'flush', 'lines', 'read', 'seek', 'setvbuf', 'write'}) then
            w = 'file:' .. f
          elseif is_in(f, {'clock', 'date', 'difftime', 'execute', 'exit', 'getenv', 'rename', 'setlocale', 'time', 'tmpname'}) then
            w = 'os.' .. f
          elseif is_in(f, {'input', 'open', 'output', 'popen', 'stderr', 'stdin', 'stdout', 'tmpfile', 'type'}) then
            w = 'io.' .. f
          elseif is_in(f, {'create', 'isyieldable', 'resume', 'running', 'status', 'wrap', 'yield'}) then
            w = 'coroutine.' .. f
          elseif is_in(f, {'config', 'cpath', 'loaded', 'loadlib', 'path', 'preload', 'searchers', 'searchpath'}) then
            w = 'package.' .. f
          elseif is_in(f, {'charpattern', 'codepoint', 'codes', 'offset'}) then
            w = 'utf8.' .. f
          elseif is_in(f, {'debug', 'gethook', 'getinfo', 'getlocal', 'getmetatable', 'getregistry', 'getupvalue', 'getuservalue',
            'sethook', 'setlocal', 'setmetatable', 'setupvalue', 'setuservalue', 'traceback', 'upvalueid', 'upvaluejoin'}) then
            w = 'debug.' .. f
          end
          url = url .. '#pdf-' .. w
        else
          url = url .. '#' .. w
        end
      end
    end
    open_url(url)
  end
})

command.add(nil, {
  ["mathly:start-interpreter"] = start_interpreter
})

command.add(nil, {
  ["mathly:insert-mathly-plot-template"] = function ()
    local doc = core.active_view.doc
    local template = [[-- axissquare()    -- axisnotsquare()    -- invalid for a grid of subplots
-- showaxes()      -- shownotaxes()      --
-- showxaxis()     -- shownotxaxis()     --
-- showyaxis()     -- shownotyaxis()     --
-- showgridlines() -- shownotgridlines() --
-- showlegend()    -- shownotlegend()
options = {
  -- xrange = {-5, 5},
  -- yrange = {-5, 5},
  -- names = {'name_of_first_graph', ...}, -- run first: showlegend()
  -- layout = {
    -- width = 600, height = 450, -- default setting
    -- title = "Example",
    -- xaxis = {title = "Your x label"}, yaxis = {title = "Your y label"},
    -- grid = {
    --   rows = 2, columns = 3,
    --   xranges = {{-5, 5}, nil,     {0, 5}, ...},
    --   yranges = {{0, 10}, {-1, 2}, nil,    ...}
    -- },
    -- gridaxes = {
    --   xaxis  = {title = "x label 1"}, yaxis  = {title = "y label 1"},
    --   xaxis2 = {title = "x label 2"}, yaxis2 = {title = "y label 2"},
    --   -- xaxis3, yaxis3 ...
    -- },
    -- margin = {l = 10, r = 40, t = 40, b = 40, pad = 10},
    -- autosize = false
  -- }
}
plot(data_functions_and_styles, options)
]]
    if doc then doc:text_input(template) end
  end
})

local translate = require "core.doc.translate"
local dv = require "core.docview"

local function change_case(f)
  local doc = core.active_view.doc
  local nosel = false
  if not doc:has_any_selection() then
    for idx, line1, _, line2 in doc:get_selections(true) do
      if line2 >= #doc.lines then
        doc:insert(line2, math.huge, "\n")
      end
      doc:set_selections(idx, line1, 1, line2 + 1, 1)
    end
    nosel = true
  end
  doc:replace(f)
  if nosel then doc:move_to(dv.translate["next_line"], core.active_view) end
end

command.add(nil, {
  ["mathly:upper-case"] = function() change_case(string.uupper) end
})

command.add(nil, {
  ["mathly:lower-case"] = function() change_case(string.ulower) end
})

local keymap = require "core.keymap"
keymap.add_direct {
  ["f1"] = "mathly:send-lua-help",
  ["f2"] = "mathly:start-interpreter",

  ["ctrl+,"]       = "mathly:send-selection",
  ["ctrl+."]       = "mathly:send-all",
  ["shift+return"] = "mathly:send-selection", -- not a good choice while starting Firefox
  ["ctrl+return"]  = "mathly:send-all",
  ["ctrl+t"]       = "mathly:insert-mathly-plot-template",

  ["ctrl+shift+l"] = "mathly:lower-case",
  ["ctrl+shift+u"] = "mathly:upper-case",

  ["ctrl+shift+r"] = "trim-whitespace:trim-trailing-whitespace",
  ["ctrl+shift+a"] = "trim-whitespace:trim-empty-end-lines",

  ["ctrl+0"]       = "bracket-match:move-to-matching",
  ["ctrl+shift+0"] = "bracket-match:select-to-matching",

  ["ctrl+shift+e"] = "find-replace:select-add-all",
}

