import os
import re
import sys
import subprocess  # dwang for Perl Inline Scripting
from cudatext import *
import cudatext_keys as keys
import cudatext_cmd as cmds

from cudax_lib import get_translation,get_opt
_ = get_translation(__file__)  # I18N

if os.name=='nt':
    browser = 'C:/Program Files/Mozilla Firefox/firefox.exe'
    lua_doc_folder = 'C:/mathly/doc/'
    mathlylua_cmd = "c:\\mathly\\bin\\lua.exe -i -e \"mathly = require(\\\"mathly\\\")\"\r"
else:
    browser = 'firefox'
    lua_doc_folder = '/usr/local/share/lua/doc/'
    mathlylua_cmd = "lua -i -e 'mathly = require(\"mathly\")'\r"

# extension : interactive interpreter # perl & gawk are not interactive
interpreters = {
    'jl': 'julia', 'm': 'octave', 'py': 'python', 'r': 'R',
    'lua': 'lua', 'rb': 'irb', 'bc': 'bc', 'sh' : 'bash',
    'html' : 'lua', 'htm' : 'lua' # for dwang's needs
}

lua_manual_url = 'file:///' + lua_doc_folder + 'manual.html'
lua_ref_manual_url = 'file:///' + lua_doc_folder + 'lua5_4.html'
mathly_manual_url = 'file:///' + lua_doc_folder + 'mathly.html'

interpreter_started = False

MIN_WINDOWS_VER = '10.0.17763'
os_ok = True
if os.name=='nt':
    import platform
    def versiontuple(v):
        return tuple(map(int, (v.split(".")))) if v and '.' in v else (0,0,0)
    version_need = versiontuple(MIN_WINDOWS_VER)
    version_our = versiontuple(platform.version())

    if version_our < version_need:
        msg_box(_('ExTerminal does not support Windows older than 10'), MB_OK+MB_ICONERROR)
        os_ok = False

if os_ok:
    from .terminal import Terminal
else:
    Terminal = None


TERMINALS_LIMIT = 4

SHELL_UNIX = 'bash'
SHELL_MAC = 'bash'
SHELL_WIN = 'cmd'
IS_WIN = os.name=='nt'
IS_MAC = sys.platform=='darwin'

opt_colors = False
opt_esc_focuses_editor = False
opt_show_caption = False
opt_themed = False
opt_ctrl_c = False
opt_ctrl_x = False
opt_ctrl_v = False

def str_to_bool(s): return s=='1'
def bool_to_str(v): return '1' if v else '0'


fn_icon = os.path.join(os.path.dirname(__file__), 'icons8-console-30.png')
ini = os.path.join(app_path(APP_DIR_SETTINGS), 'plugins.ini')
section = 'exterminal'

def is_word_char(c):
    return c.isalnum() or (c in "_-:.") # lua: file:open, io.write

def caret_info(ed, r_click=False):
    if r_click:
        x, y = app_proc(PROC_GET_MOUSE_POS, '')
        x, y = ed.convert(CONVERT_SCREEN_TO_LOCAL, x, y)
        x, y = ed.convert(CONVERT_PIXELS_TO_CARET, x, y)
        x2, y2 = -1, -1
    else:
        x, y, x2, y2 = ed.get_carets()[0]

    line = ed.get_text_line(y)
    if not line: return
    if not (0 <= x < len(line)) or not is_word_char(line[x]): return None

    n1 = x
    n2 = x + 1
    while n1 > 0 and is_word_char(line[n1 - 1]):
        n1 -= 1
    while n2 < len(line) and is_word_char(line[n2]):
        n2 += 1
    x = n1

    return locals()

def get_current_word_under_caret(ed, r_click=False):
    info = caret_info(ed, r_click)
    if info:
        return info['line'][info['n1']:info['n2']]
    else:  # bug, dwang
        return ''

import cudatext as app
def ed_of_file_open(op_file):  # borrowed from Find in Files
    if not app.file_open(op_file):
        return None
    for h in app.ed_handles():
        op_ed   = app.Editor(h)
        if op_ed.get_filename() and os.path.samefile(op_file, op_ed.get_filename()):
            return op_ed
    return None
#def ed_of_file_open

def nav_as(path, x1, y1, x2, y2): # borrowed from Find in Files
    op_ed = None
    if path.startswith('tab:'):
        tab_id  = int(path.split('/')[0].split(':')[1])
        pass;                   NAVLOG and log('tab_id={}',(tab_id))
        op_ed   = apx.get_tab_by_id(tab_id)
        if not op_ed:                   return  msg_status(_("No tab for navigation"))
    else:
        if not os.path.isfile(path):    return  msg_status(_("No file for navigation"))
        op_ed   = ed_of_file_open(path)
        if not op_ed:
            app.file_open(path)
            op_ed   = ed
    op_ed.set_caret(x1, y1, x2, y2)
#def nav_as

class Command:
    def __init__(self):
        self.load_ops()
        self.terminal_id = 0
        self.terminals = []
        self.last_touched = None
        self.h_menu = None

    def load_ops(self):
        self.shell_unix = ini_read(ini, section, 'shell_unix', SHELL_UNIX)
        self.shell_mac = ini_read(ini, section, 'shell_macos', SHELL_MAC)
        self.shell_win = ini_read(ini, section, 'shell_windows', SHELL_WIN)
        if IS_WIN: self.shell_str = self.shell_win
        else: self.shell_str = self.shell_mac if IS_MAC else self.shell_unix

        global opt_colors
        global opt_esc_focuses_editor
        global opt_show_caption
        global opt_themed
        global opt_ctrl_c
        global opt_ctrl_x
        global opt_ctrl_v
        opt_colors   = str_to_bool(ini_read(ini, section, 'colors',   '0'))
        opt_esc_focuses_editor = str_to_bool(ini_read(ini, section, 'esc_focuses_editor', '0'))
        opt_show_caption = str_to_bool(ini_read(ini, section, 'show_caption', '0'))
        opt_themed = str_to_bool(ini_read(ini, section, 'themed', '0'))
        opt_ctrl_c = str_to_bool(ini_read(ini, section, 'ctrl_c', '0'))
        opt_ctrl_x = str_to_bool(ini_read(ini, section, 'ctrl_x', '0'))
        opt_ctrl_v = str_to_bool(ini_read(ini, section, 'ctrl_v', '0'))

    def save_ops(self, only_size=False):
        ini_write(ini, section, 'shell_windows', self.shell_win)
        ini_write(ini, section, 'shell_unix', self.shell_unix)
        ini_write(ini, section, 'shell_macos', self.shell_mac)
        ini_write(ini, section, 'colors',   bool_to_str(opt_colors))
        ini_write(ini, section, 'esc_focuses_editor', bool_to_str(opt_esc_focuses_editor))
        ini_write(ini, section, 'show_caption', bool_to_str(opt_show_caption))
        ini_write(ini, section, 'themed', bool_to_str(opt_themed))
        ini_write(ini, section, 'ctrl_c', bool_to_str(opt_ctrl_c))
        ini_write(ini, section, 'ctrl_x', bool_to_str(opt_ctrl_x))
        ini_write(ini, section, 'ctrl_v', bool_to_str(opt_ctrl_v))

    def config(self):
        self.save_ops()
        file_open(ini)
        lines = [ed.get_text_line(i) for i in range(ed.get_line_count())]
        try:
            index = lines.index('['+section+']')
            ed.set_caret(0, index)
        except:
            pass

    def open(self):
        if not os_ok:
            return
        self.new_terminal_tab()

    def new(self):
        self.new_terminal_tab(focus=True)

    def close_all(self):
        for t in self.terminals:
            t.close()
            del t
        self.terminals = []
        ed.cmd(cmds.cmd_ShowPanelConsole)
        ed.focus()

    def new_terminal_tab(self,focus=False):
        if len(self.terminals) >= TERMINALS_LIMIT:
            msg_box(_("More than {} terminals is not supported yet.").format(TERMINALS_LIMIT), MB_OK+MB_ICONINFO)
            return
        Terminal.themed = opt_themed
        self.set_font_size()

        self.terminal_id += 1
        t = Terminal("ExTerminal {}".format(self.terminal_id),
            self.shell_str,
            opt_esc_focuses_editor,
            fn_icon,
            opt_colors,
            opt_show_caption,
            opt_ctrl_c,
            opt_ctrl_v,
            opt_ctrl_x
            )
        t.form_show_callback = self.form_show_callback
        t.open()
        if focus:
            t.memo.focus()
        self.terminals.append(t)

    def form_show_callback(self, t):
        self.last_touched = t

    def ensure_at_least_one_terminal(self, focus=False):
        # ensure there is at least one terminal
        if len(self.terminals) == 0:
            self.new_terminal_tab(focus=focus)
            # wait for shell
            while self.terminals[0].shell is None:
                app_idle()
                if self.terminals[0].shell == False:
                    # error while executing shell, break from loop
                    break

    def get_active_terminal(self):
        self.ensure_at_least_one_terminal()

        # return visible one
        for t in self.terminals:
            if dlg_proc(t.h_dlg, DLG_PROP_GET)['vis']:
                return t

        # if terminals are hidden
        return self.last_touched

    def mathly_plot_template(self):
        carets = ed.get_carets()
        x1, y1, x2, y2 = carets[0]
        ed.set_caret(x1, y1)
        ed.insert(x1, y1, '''-- axissquare()    -- axisnotsquare()    -- invalid for a grid of subplots
-- showaxes()      -- shownotaxes()      --
-- showxaxis()     -- shownotxaxis()     --
-- showyaxis()     -- shownotyaxis()     --
-- showgridlines() -- shownotgridlines() --
-- showlegend()    -- shownotlegend()
options = {
  -- xrange = {-5, 5},
  -- yrange = {-5, 5},
  -- names = {'name_of_first_graph', ...}, -- run first: showlegend()
  -- layout = {
    -- width = 600, height = 450, -- default setting
    -- title = "Example",
    -- xaxis = {title = "Your x label"}, yaxis = {title = "Your y label"},
    -- grid = {
    --   rows = 2, columns = 3,
    --   xranges = {{-5, 5}, nil,     {0, 5}, ...},
    --   yranges = {{0, 10}, {-1, 2}, nil,    ...}
    -- },
    -- gridaxes = {
    --   xaxis  = {title = "x label 1"}, yaxis  = {title = "y label 1"},
    --   xaxis2 = {title = "x label 2"}, yaxis2 = {title = "y label 2"},
    --   -- xaxis3, yaxis3 ...
    -- },
    -- margin = {l = 10, r = 40, t = 40, b = 40, pad = 10},
    -- autosize = false
  -- }
}
plot(data_functions_and_styles, options)
''')

    def show_terminal(self, t):
        app_proc(PROC_BOTTOMPANEL_ACTIVATE, t.name)

    def run_selection(self):
        global interpreter_started
        if not interpreter_started:
            self.start_interpreter()

        t = self.get_active_terminal()
        if t:
            self.show_terminal(t)

            txt = ed.get_text_sel()
            if txt:
                for line in txt.split('\n'):
                    t.write(line+'\r')
            else: # if no selection -> run whole line
                caret = ed.get_carets()[0]
                x, y = caret[0:2]
                txt = ed.get_text_line(y).rstrip('\n')
                if txt:
                    t.write(txt+'\r')
                # move caret down
                if y+1 < ed.get_line_count():
                    ed.set_caret(x, y+1)

    def run_current_file(self):
        global interpreter_started
        if not interpreter_started:
            self.start_interpreter()

        fn = ed.get_filename()
        if fn:
            t = self.get_active_terminal()
            if t:
                self.show_terminal(t)
                t.write('"'+fn+'"\r')

    def cd_current_file_directory(self):
        fn = ed.get_filename()
        head, tail = os.path.split(fn)
        if fn:
            t = self.get_active_terminal()
            if t:
                self.show_terminal(t)
                head = re.sub(r"\\", "/", head) # for windows, dwang
                if os.name=='nt':
                    drive = head[0:2]
                    t.write('\r' + drive)
                t.write('\rcd "'+head+'"\r')
                os.chdir(head)

    def toggle_focus(self):
        if len(self.terminals) == 0:
            self.ensure_at_least_one_terminal(focus=True)
            return

        t = self.get_active_terminal()
        if t is None:
            return
        if not t.memo.get_prop(PROP_FOCUSED):
            self.show_terminal(t)
            t.memo.focus()
        else:
            ed.focus()

    def close_terminal(self, caption):
        for t in self.terminals[:]:
            if t.name == caption:
                t.close()
                self.terminals.remove(t)
                ed.cmd(cmds.cmd_HideBottomPanel)
                return

    def on_sidebar_popup(self, ed_self, caption):
        if 'ExTerminal' in caption:
            if self.h_menu is None:
                self.h_menu = menu_proc(0, MENU_CREATE)
            else:
                menu_proc(self.h_menu, MENU_CLEAR)
            menu_proc(self.h_menu, MENU_ADD, caption=_("New terminal"), command=self.new )
            h_menu_close = menu_proc(self.h_menu, MENU_ADD, caption=_("Close terminal"), command=lambda: self.close_terminal(caption) )
            if not self.terminals:
                menu_proc(h_menu_close, MENU_SET_ENABLED, command=False)
            menu_proc(self.h_menu, MENU_SHOW)

    def on_state(self, ed_self, state):
        if state == APPSTATE_CONFIG_REREAD:
            self.set_font_size()
        elif state == APPSTATE_THEME_UI:
            Terminal.themed = opt_themed
            for t in self.terminals:
                t.set_theme_colors()

    def set_font_size(self):
        _os_suffix = app_proc(PROC_GET_OS_SUFFIX, '')
        Terminal.font_size = get_opt('font_size'+_os_suffix)


    def run_script(self):
        global interpreter_started, browser
        if not interpreter_started:
            self.start_interpreter()

        fname = ed.get_filename(options='*')
        ext = fname.split('.')[-1].lower()
        if ext == 'html' or ext == 'htm':
            subprocess.Popen([browser, fname])
        else:
            t = self.get_active_terminal()
            if t:
                self.show_terminal(t)
                txt = ed.get_text_all()
                if txt:
                    for line in txt.split('\n'):
                        t.write(line+'\r')

    def start_interpreter(self):
        t = self.get_active_terminal()
        if t:
            global interpreter_started, interpreters, mathlylua_cmd
            interpreter_started = True
            self.show_terminal(t)
            fname = ed.get_filename(options='*')

            ext = fname.split('.')[-1]
            interpreter = interpreters.get(ext.lower())
            if interpreter == None:
                interpreter = 'lua'
                if ext == '': # no extension, e.g., Untitled1
                    ed.set_prop(PROP_LEXER_FILE, 'lua')

            self.cd_current_file_directory()
            if interpreter == 'lua':
                t.write(mathlylua_cmd)
            elif interpreter == 'python':
                ed.cmd(cmds.cmd_ShowPanelConsole)
            elif interpreter != 'perl':
                t.write(interpreter + '\r')

    def help_on_function(self):
        w = get_current_word_under_caret(ed)
        global browser, lua_manual_url, lua_ref_manual_url, mathly_manual_url, interpreters
        fname = ed.get_filename(options='*')
        interpreter = interpreters.get(fname.split('.')[-1].lower())

        if w == '':
            url = mathly_manual_url
        else:
            mathlyq = w in [ # is w a mathly function?
                'all', 'animate', 'any', 'apply', 'arc', 'axisnotsquare', 'axissquare', 'bin2dec', 'bin2hex', 'bin2oct', 'boxplot',
                'cat', 'cc', 'circle', 'clc', 'clear', 'contourplot', 'copy', 'corr', 'cross', 'dec2bin', 'dec2hex', 'dec2oct',
                'demathly', 'det', 'diag', 'diff', 'diff1', 'diff2', 'dir', 'directionfield', 'disp', 'display', 'div', 'dot',
                'dotplot', 'eps', 'eval', 'expand', 'eye', 'findroot', 'fliplr', 'flipud', 'format','freqpolygon', 'fstr2f',
                'fzero', 'gcd', 'hasindex', 'hex2bin', 'hex2dec', 'hex2oct', 'hist', 'hist1', 'histfreqpolygon', 'horzcat',
                'input', 'integral', 'integral2', 'integral3', 'inv', 'isdir', 'isempty', 'iseven', 'isfile', 'isinteger', 'ismatrix',
                'ismember', 'isodd', 'isvector', 'iswindows', 'lagrangepoly', 'length', 'line', 'linsolve', 'linspace',
                'ls', 'lu', 'manipulate', 'map', 'match', 'mathly', 'max', 'mean', 'merge', 'min', 'mod', 'mv', 'namedargs',
                'newtonpoly', 'norm', 'oct2bin', 'oct2dec', 'oct2hex', 'ones', 'parametriccurve2d', 'pareto', 'pie', 'plot',
                'plot3d', 'plotparametriccurve2d', 'plotparametriccurve3d', 'plotparametricsurface3d', 'plotsphericalsurface3d',
                'point', 'polarcurve2d', 'polyfit', 'polygon', 'polynomial', 'polyval', 'powermod', 'printf', 'prod', 'pwd', 'qq', 'qr', 'rand',
                'randi', 'randn', 'range', 'remake', 'repmat', 'reshape', 'reverse', 'rm', 'round', 'rr', 'rref', 'save', 'scatter',
                'seq', 'showaxes', 'showgridlines', 'showlegend', 'shownotlegend', 'shownotaxes', 'shownotgridlines', 'shownotxaxis',
                'shownotyaxis', 'showxaxis', 'showyaxis', 'size', 'sleep', 'slopefield', 'sort', 'sprintf', 'std', 'strcat',
                'submatrix', 'subtable', 'sum', 'tables', 'tblcat', 'text', 'tic', 'toc', 'transpose', 'tt', 'unique', 'var',
                'vectorangle', 'vectorfield2d', 'vertcat', 'wedge', 'who', 'zeros']
            basicq = (not mathlyq) and w in [
                'abs', 'acos', 'asin', 'atan', 'ceil', 'cos', 'deg', 'e', 'eps', 'exp', 'floor', 'log', 'log10', 'phi',
                'pi', 'rad', 'random', 'sin', 'sqrt', 'tan']
            if mathlyq:
                url = mathly_manual_url + '#' + w
            elif basicq:
                url = mathly_manual_url + '#math'
            else:
                url = lua_manual_url
                if w[:4] != 'lua_' and w[:4] != 'luaL':
                    import re
                    regex = re.compile(r'.*[:|\.](.+)')
                    match = regex.search(w)
                    if match != None:
                        f = match.group(1)
                        if f in ['concat', 'insert', 'move', 'pack', 'remove', 'sort', 'unpack']:
                            w = 'table.' + f
                        elif f in ['dump', 'find', 'byte', 'format', 'gmatch', 'gsub', 'len', 'lower', 'match', 'char',
                            'packsize', 'rep', 'reverse', 'sub', 'upper']:
                            w = 'string.' + f
                        elif f in ['close', 'flush', 'lines', 'read', 'seek', 'setvbuf', 'write']:
                            w = 'file:' + f
                        elif f in ['clock', 'date', 'difftime', 'execute', 'exit', 'getenv', 'rename', 'setlocale', 'time', 'tmpname']:
                            w = 'os.' + f
                        elif f in ['input', 'open', 'output', 'popen', 'stderr', 'stdin', 'stdout', 'tmpfile', 'type']:
                            w = 'io.' + f
                        elif f in ['create', 'isyieldable', 'resume', 'running', 'status', 'wrap', 'yield']:
                            w = 'coroutine.' + f
                        elif f in ['config', 'cpath', 'loaded', 'loadlib', 'path', 'preload', 'searchers', 'searchpath']:
                            w = 'package.' + f
                        elif f in ['charpattern', 'codepoint', 'codes', 'offset']:
                            w = 'utf8.' + f
                        elif f in ['debug', 'gethook', 'getinfo', 'getlocal', 'getmetatable', 'getregistry', 'getupvalue',
                            'getuservalue', 'sethook', 'setlocal', 'setmetatable', 'setupvalue', 'setuservalue', 'traceback',
                            'upvalueid', 'upvaluejoin']:
                            w = 'debug.' + f
                    url += '#pdf-' + w
                else:
                    url += '#' + w
        subprocess.Popen([browser, url])

    def goto_file_in_FindInFiles_results(self):
        # get current line
        line_number = ed.get_carets()[0][1]  # Get the line number of the first caret
        line_text = ed.get_text_line(line_number)
        line = start = stop = fname = None
        if m := re.match(r"^\s*\<\(\s*(\d+)\s*:\s*(\d+)\s*:\s*(\d+)\s*\)\>:\s+", line_text): # results of Find in Files, <( 1: 1:6)>:
            line  = m.group(1)
            start = m.group(2)
            stop  = m.group(3)
        elif m := re.match(r"^\s*\<\s*(\d+)\s*\>:\s+", line_text): # results of Find in Files, < 1>:
            line = m.group(1)
        elif m := re.match(r"^(.+\.lua)\s*\:\s*(\d+)\s*\:\s", line_text): # demo.lua:94: syntax error near 'require'
            line = m.group(2)
            fname = m.group(1)
            _, fname = os.path.split(fname)
            fname = os.getcwd() + '/' + fname
            fname = re.sub(r"\\", "/", fname)

        if not (line is None) and fname is None:
            while line_number > 0:
                line_number -= 1
                line_text = ed.get_text_line(line_number)
                # <F:\archive\liberty\courses\352\slides\code\lua+mathly\03-find-roots\secant_script.lua>: #5
                if m := re.match(r"^\s*\<(.+)>:\s*#\d+\s*$", line_text):
                    fname = m.group(1)
                    break

        if not (fname is None):
            x1 = 0; x2 = -1
            y1 = y2 = int(line) - 1
            if start is None:
                y2 = -1
            else:
                x1 = int(start) - 1
                x2 = int(start) + int(stop) - 1
            nav_as(fname, x1, y1, x2, y2)

    def lua_ref_manual(self):
        global browser, lua_ref_manual_url
        subprocess.Popen([browser, lua_ref_manual_url])

    def mathly_manual(self):
        global browser, mathly_manual_url
        subprocess.Popen([browser, mathly_manual_url])
