ch_user = []
ch_def = [
  'https://raw.githubusercontent.com/Alexey-T/CudaText-registry/master/json/plugins.json',
  'https://raw.githubusercontent.com/Alexey-T/CudaText-registry/master/json/linters.json',
  'https://raw.githubusercontent.com/Alexey-T/CudaText-registry/master/json/data.json',
  'https://raw.githubusercontent.com/Alexey-T/CudaText-registry/master/json/snippets.json',
  'https://raw.githubusercontent.com/Alexey-T/CudaText-registry/master/json/lexers.json',
  'https://raw.githubusercontent.com/kvichans/CudaText-registry/master/kv-addons.json',
  ]
proxy = ''
cache_minutes = 10
suggest_readme = True
install_confirm = True
download_timeout = 9 # in seconds
verify_https = True
sf_mirror = '' # SF.net mirror id, like 'voxel'
