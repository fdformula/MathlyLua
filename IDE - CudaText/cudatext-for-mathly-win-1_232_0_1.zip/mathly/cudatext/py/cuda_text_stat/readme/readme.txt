plugin for CudaText.
gets statistics for text in the current editor tab.
and shows it in a message-box, also allowing to output report to a new file.
gets info:

- count of lines/ all chars/ letter chars
- count of words (with alpha-numerical chars)
- most common words (up to 30, can change this number in source code)
- count of sentences which have n (1 to 9) words
- additional command: find all sentences, and output them to a new tab


authors:
  Alexey Torgashin (CudaText)
  ildarkhasanshin on GitHub
license: MIT
