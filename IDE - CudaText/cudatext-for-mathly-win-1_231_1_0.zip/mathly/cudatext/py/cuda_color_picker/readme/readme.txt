plugin for CudaText.
gives commands in "Plugins" menu.

1) show Color Picker dialog.
dialog is native for OS.

if caret is placed on HTML color token, e.g. #f0a020 or #ab0, dialog must show this color first.
on closing Color Picker with OK, plugin inserts chosen color (in form #rrggbb) into text.

2) command to show listbox with recently chosen colors.
this list is saved to settings/plugins.ini (up to 30 items).


author: Alexey Torgashin (CudaText)
license: MIT
